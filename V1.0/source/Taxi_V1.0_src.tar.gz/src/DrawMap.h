#ifndef DRAWMAP_H_INCLUDED_
#define DRAWMAP_H_INCLUDED_

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include "GuberClient.h"
#include "Reader.h"
#include <gtk/gtk.h>
#include <assert.h>

#endif
